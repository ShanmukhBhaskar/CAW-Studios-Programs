package com.Test;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

import static org.testng.Assert.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.concurrent.TimeUnit;

public class MainPageTest {
    private WebDriver driver;
    private MainPage mainPage;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.gecko.driver", "C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://testpages.herokuapp.com/styled/tag/dynamic-table.html");

        mainPage = new MainPage(driver);
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }

    public void findValue(String key){

        boolean keyFound = false;
        java.util.List<WebElement> rows = mainPage.generatedTable.findElements(By.tagName("tr"));
        for (WebElement row : rows) {
        	java.util.List<WebElement> columns = row.findElements(By.tagName("td"));
            if (!columns.isEmpty() && columns.get(0).getText().equals(key)) {
                keyFound = true;
                System.out.println("Requested Row Data:");
                for (WebElement column : columns) {
                    System.out.print(column.getText() + "\t");
                }
                System.out.println();
                break;
            }
        }

        if(!keyFound)
        	System.out.println("The requested key" + key + " is not present in the table");


    }

    @Test
    public void testJsonData() throws InterruptedException {
        mainPage.table.click();
        mainPage.data.clear();
        mainPage.data.sendKeys(mainPage.jsonData);
        mainPage.refreshTable.click();
        Thread.sleep(3000);
        findValue("Bob");
        findValue("George");
    }


}
