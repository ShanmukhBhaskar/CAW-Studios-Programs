package com.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MainPage {

    @FindBy(xpath = "//*[text()='Table Data']")
    public WebElement table;

    @FindBy(id = "jsondata")
    public WebElement data;

    @FindBy(id= "refreshtable")
    public WebElement refreshTable;

    @FindBy(id="dynamictable")
    public WebElement generatedTable;

    public String url = "https://testpages.herokuapp.com/styled/tag/dynamic-table.html";

    public String jsonData = "[{\"name\" : \"Bob\", \"age\" : 20, \"gender\": \"male\"}, {\"name\": \"George\", \"age\" : 42, \"gender\": \"male\"}, {\"name\": \"Sara\", \"age\" : 42, \"gender\": \"female\"}, {\"name\": \"Conor\", \"age\" : 40, \"gender\": \"male\"}, {\"name\": \"Jennifer\", \"age\" : 42, \"gender\": \"female\"}]";

    public MainPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }
}
